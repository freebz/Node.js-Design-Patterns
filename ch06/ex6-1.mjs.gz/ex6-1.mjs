// 6-1-2 공간 효율성

import buffer from 'buffer'
console.log(buffer.constants.MAX_LENGTH)